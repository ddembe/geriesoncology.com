**Related Issue**
This PR's content was first discussed in issue #

**Dependency Changes**
If relevant, list any dependencies added, removed, or changed.

**Testing**
- [ ] Built and tested to work on a standalone Hugo site
- [ ] Built and tested to work in the Hugo Theme Gallery demo site ([link](https://github.com/gohugoio/hugoThemes/blob/master/README.md))
- [ ] Tested with browser's responsive-design tools

**Additional context**
Add any other context about the pull request here.
