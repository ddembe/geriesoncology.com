---
title: "About The Theme"
menu: "main"
draft: false
---

Indigo is a lightweight theme for [Hugo][hugo] with [IndieWeb][indieweb] features baked in. It's great for longer-form blogging, placing its focus on distraction-free reading and beautiful typefaces.

Read more about the theme [here][intro].

[hugo]: https://gohugo.io
[indieweb]: https://indieweb.org/
[intro]: /post/introducing-indigo