npm run algolia
